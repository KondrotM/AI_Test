package uk.ac.glos.ct5055;

public class Main {

    public static void main(String[] args){

        new BayesianNetworkTest().testEncog();
    }
}
